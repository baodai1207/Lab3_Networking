NAME: DAI HUYNH
CSCI 3761
Student ID: 107057706

                                                                LAB 3
Description:
We have discussed the usage of minimum spanning tree when you try to extend LAN segments with link-layer switches (bridges). In this programming assignment, you will be implementing Minimum Spanning Tree (MST) Algorithm with either C or C++.
The program will use Prim's Algorithm for Minimum Spanning Tree
I have tested 3 different input files includes: input10.txt (in lab3 description), input_10.txt and input_100.txt (TA provided) and the program have run successfully.

How to build and run program:

The homework file is compressed in zip file. To uncompress, we need to follow commands % unzip huy7706.zip

Now you should see a directory with the files: mst.cpp

Build the program.

1) RUN SERVER
We change to the directory: %cd huy7706

Then compile the program: % make

Run the program: %./mymst

The program will prompt you to enter the name file input.

After you entered the name file, hit enter. The program will run and will give the expect result.

Delete all the objectives files: % ./make clean
