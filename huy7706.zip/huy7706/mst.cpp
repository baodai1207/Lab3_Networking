#include <iostream>

#include <fstream>
#include <string>
#include <chrono>

using namespace std;
using namespace chrono;

struct node
{
    int head, tail, cost;
};

string inFile;

int node_num;
int total_min_cost = 0;

int main()
{

    cout << "Enter text input file: ";
    cin >> inFile;
    ifstream input_file;
    auto start = high_resolution_clock::now();
    input_file.open(inFile);

    if (input_file.fail())
    {
        cout << "File is invalid" << endl;
    }
    else
    {
        input_file >> node_num;

        int firstNode = 0;
        int secondNode = 0;

        int **buffer;

        buffer = new int *[node_num];
        for (int i = 0; i < node_num; i++)
            buffer[i] = new int[node_num];

        while (!input_file.eof())
        {
            input_file >> firstNode;
            input_file >> secondNode;
            input_file >> buffer[firstNode - 1][secondNode - 1];
        }

        input_file.close();

        int usedNode[node_num];
        for (int i = 0; i < node_num; i++)
        {
            usedNode[i] = 0;
        }

        input_file.close();

        node *track = new node[node_num - 1];
        for (int i = 0; i < node_num - 1; i++)
        {
            track->cost = 0;
            track->head = 0;
            track->tail = 0;
        }

        int index = 0, t1 = 0, t0 = 0;
        usedNode[0] = 1;
        while (index < node_num - 1)
        {

            int min_weight = 9999;
            for (int i = 0; i < node_num; i++)
            {
                if (usedNode[i] == 1)
                {
                    for (int j = 0; j < node_num;)
                    {
                        if (buffer[i][j] >= min_weight || buffer[i][j] == 0)
                        {
                            j++;
                        }
                        else if (buffer[i][j] < min_weight)
                        {
                            if (usedNode[i] == 1 && usedNode[j] == 1)
                            {
                                j++;
                            }
                            else
                            {
                                min_weight = buffer[i][j];
                                t0 = i;
                                t1 = j;
                            }
                        }
                    }
                }
            }
            usedNode[t1] = 1;
            track[index].head = t0;
            track[index].tail = t1;
            track[index].cost = min_weight;

            index++;
            buffer[t0][t1] = buffer[t1][t0] = 10000;
        }
        auto stop = high_resolution_clock::now();

        chrono::duration<double, milli> total_time = stop - start;
        cout << "-------------------------MiniSpanningTree------------------------------------" << endl;
        cout << "Total Execution Time = " << total_time.count() << " ms" << endl << endl;
        int count = 0;
        for (int i = 0; i < node_num - 1; i++)
        {
            if (count == 9)
            {
                cout << endl;
                count = 0;
            }
            cout << "(" << track[i].head + 1 << "," << track[i].tail + 1 << ")";
            count++;
            total_min_cost += track[i].cost;
            if (i != (node_num - 2))
            {
                cout << ",";
            }
        }
        cout << endl;

        cout << "\nMinimum Cost= " << total_min_cost << endl;
    }
    cout << "-----------------------------------------------------------------------------" << endl;
    return 0;
}
